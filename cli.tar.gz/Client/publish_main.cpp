#include "publisher.hpp"
#include "consumer.hpp"
#include "s3service.pb.h"
#include "clientsocket.hpp"

#include <iostream>
#include <thread>
#include <cstddef>
#include <experimental/filesystem>
#include <bits/stdc++.h>
#include <vector>

#include <unistd.h>

std::string getRequestId()
{
	std::srand(std::time(nullptr));

	return "id" + std::to_string(std::rand());
}

auto readFromFile(clientSocket& cs, const std::string& objectPath, s3service::s3object& objRequest)
{
	std::ifstream iF(objectPath, std::ios::in | std::ios::binary);

	if (!iF)
	{
		std::cout << "File not found!";
		return false;
	}

	iF.seekg(0, std::ios::end);
	size_t size = iF.tellg();
	iF.seekg(0, std::ios::beg);

	char* data = new char[size];

	iF.read(data, size);

	auto ret = cs.writeSocket(data, size);

	if (ret != "")
	{
		std::cout << ret << std::endl;
		return false;
	}

	objRequest.set_len(size);

	iF.close();

	return true;
}

void writeToFile(clientSocket csRead, const std::string& fileName, int len)
{
	std::ofstream oF(fileName.c_str(), std::ios::out | std::ios::binary);
	std::vector<char> data;

	auto ret = csRead.readSocket(data, len);

	if (ret != "")
	{
		std::cout << ret << std::endl;
	}

    oF.write(&data[0], len);
    oF.close();
}

std::string getObjectName(const std::string& path)
{
	std::experimental::filesystem::path p(path);

	return p.filename().string();
}

void createAndPublishRequestPacket(publisher* pub)
{
	clientSocket cs("127.0.0.1", 8081);
	cs.createAndConnect();

	while (true)
	{
		s3service::serviceRequestResponse request;

		std::cout << "Which action you wanna take?:" << std::endl;
		std::cout << "1. Account" << std::endl;
		std::cout << "2. User" << std::endl;
		std::cout << "3. AccessKey" << std::endl;
		std::cout << "4. Bucket" << std::endl;
		std::cout << "5. Object" << std::endl;

		int choice;

		std::cin >> choice;

		if (choice == 1)
		{
			request.set_entitytype(s3service::serviceRequestResponse::ACCOUNT);

			auto accountRequest  = request.add_account();

			std::cout << "Which action?:" << std::endl;
			std::cout << "1. Create Account" << std::endl;
			std::cout << "2. Delete Account" << std::endl;

			std::cin >> choice;

			std::cout << "Enter account name: ";

			std::string accountName, password;

			std::cin >> accountName;

			accountRequest->set_accountname(accountName);

			std::cout << "Enter password: ";

			std::cin >> password;

			accountRequest->set_password(password);

			if (choice == 1)
			{
				accountRequest->set_accop(s3service::s3account::CREATE_ACCOUNT);
			}
			else
			{
				accountRequest->set_accop(s3service::s3account::DELETE_ACCOUNT);
			}
		}
		else if (choice == 2)
		{
			request.set_entitytype(s3service::serviceRequestResponse::USER);

			auto userRequest  = request.add_user();

			std::cout << "Which action?:" << std::endl;
			std::cout << "1. Create User" << std::endl;
			std::cout << "2. Update User" << std::endl;
			std::cout << "3. Delete Account" << std::endl;

			std::cin >> choice;

			std::string accessKey, secretKey;

			std::cout << "Enter Anthorization keys: " << std::endl;
			std::cout << "AccessKey: ";

			std::cin >> accessKey;

			std::cout << "SecretKey: ";

			std::cin >> secretKey;

			auto auth = userRequest->add_auth();

			auth->set_accesskey(accessKey);
			auth->set_secretkey(secretKey);

			std::cout << "Enter userName: ";

			std::string userName;

			std::cin >> userName;

			userRequest->set_username(userName);

			if (choice == 1)
			{
				userRequest->set_userop(s3service::s3user::CREATE_USER);
			}
			else if (choice == 2)
			{
				std::cout << "Enter New username: ";
				std::string newName;

				std::cin >> newName;

				userRequest->set_newusername(newName);

				userRequest->set_userop(s3service::s3user::UPDATE_USER);
			}
			else
			{
				userRequest->set_userop(s3service::s3user::DELETE_USER);
			}
		}
		else if (choice == 3)
		{
			request.set_entitytype(s3service::serviceRequestResponse::ACCESSKEY);

			auto keyRequest  = request.add_accesskey();

			std::cout << "Which action?:" << std::endl;
			std::cout << "1. Create Key" << std::endl;
			std::cout << "2. Delete Key" << std::endl;
			std::cout << "3. Change Status" << std::endl;
			std::cout << "4. Get Last Used Time" << std::endl;

			std::cin >> choice;

			std::string accessKey, secretKey;

			std::cout << "Enter Anthorization keys: " << std::endl;
			std::cout << "AccessKey: ";

			std::cin >> accessKey;

			std::cout << "SecretKey: ";

			std::cin >> secretKey;

			auto auth = keyRequest->add_auth();

			auth->set_accesskey(accessKey);
			auth->set_secretkey(secretKey);

			std::cout << "Enter userName: ";

			std::string userName;

			std::cin >> userName;

			keyRequest->set_username(userName);

			if (choice == 1)
			{
				keyRequest->set_accessop(s3service::s3accesskey::CREATE_KEY);
			}
			else if (choice == 2)
			{
				std::cout << "Enter accessKeyId ";

				std::cin >> accessKey;

				keyRequest->set_accesskeyid(accessKey);

				keyRequest->set_accessop(s3service::s3accesskey::DELETE_KEY);
			}
			else if (choice == 3)
			{
				std::cout << "Enter accessKeyId ";

				std::cin >> accessKey;

				keyRequest->set_accesskeyid(accessKey);

				std::cout << "Enter new status:(Active, Inactive) ";

				std::string status;

				std::cin >> status;

				keyRequest->set_status(status);

				keyRequest->set_accessop(s3service::s3accesskey::CHANGE_KEY_STATUS);
			}
			else
			{
				std::cout << "Enter accessKeyId ";

				std::cin >> accessKey;

				keyRequest->set_accesskeyid(accessKey);

				keyRequest->set_accessop(s3service::s3accesskey::LAST_USED_TIME);
			}
		}
		else if (choice == 4)
		{
			request.set_entitytype(s3service::serviceRequestResponse::BUCKET);

			auto bucketRequest  = request.add_bucket();

			std::cout << "Which action?:" << std::endl;
			std::cout << "1. Create Bucket" << std::endl;
			std::cout << "2. Delete Bucket" << std::endl;
			std::cout << "3. Put Bucket Tag" << std::endl;
			std::cout << "4. Get Bucket Tag" << std::endl;

			std::cin >> choice;

			std::string accessKey, secretKey;

			std::cout << "Enter Anthorization keys: " << std::endl;
			std::cout << "AccessKey: ";

			std::cin >> accessKey;

			std::cout << "SecretKey: ";

			std::cin >> secretKey;

			auto auth = bucketRequest->add_auth();

			auth->set_accesskey(accessKey);
			auth->set_secretkey(secretKey);

			std::string bucketName;

			std::cout << "Enter bucket name:" << std::endl;
			std::cin >> bucketName;

			bucketRequest->set_bucketname(bucketName);

			if (choice == 1)
			{
				bucketRequest->set_buckop(s3service::s3bucket::CREATE_BUCKET);
			}
			else if (choice == 2)
			{
				bucketRequest->set_buckop(s3service::s3bucket::DELETE_BUCKET);
			}
			else if (choice == 3)
			{
				std::string key, value;

				std::cout << "Enter tag";

				std::cin >> key;
				std::cin >> value;

				auto tag = bucketRequest->add_tag();

				tag->set_key(key);
				tag->set_value(value);

				bucketRequest->set_buckop(s3service::s3bucket::PUT_BUCKET_TAG);
			}
			else
			{
				bucketRequest->set_buckop(s3service::s3bucket::GET_BUCKET_TAG);
			}
		}
		else if (choice == 5)
		{
			request.set_entitytype(s3service::serviceRequestResponse::OBJECT);

			auto objectRequest  = request.add_object();

			std::cout << "Which action?:" << std::endl;
			std::cout << "1. Put Object" << std::endl;
			std::cout << "2. Delete Object" << std::endl;
			std::cout << "3. Get Object"  << std::endl;

			std::cin >> choice;

			std::string accessKey, secretKey;

			std::cout << "Enter Authorization keys: " << std::endl;
			std::cout << "AccessKey: ";

			std::cin >> accessKey;

			std::cout << "SecretKey: ";

			std::cin >> secretKey;

			auto auth = objectRequest->add_auth();

			auth->set_accesskey(accessKey);
			auth->set_secretkey(secretKey);

			std::string bucketName, objectPath;

			std::cout << "Enter bucket name:" << std::endl;
			std::cin >> bucketName;

			objectRequest->set_bucketname(bucketName);

			std::cout << "Enter ObjectPath: " << std::endl;
			std::cin >> objectPath;

			auto objectName = getObjectName(objectPath);

			objectRequest->set_objectname(objectName);

			if (choice == 1)
			{

				auto ret = readFromFile(cs, objectPath, *objectRequest);

				if (ret == false)
				{
					std::cout << "readFromFile failed" << std::endl;
					continue;
				}

				objectRequest->set_objectop(s3service::s3object::PUT_OBJECT);
			}
			else if (choice == 2)
			{
				objectRequest->set_objectop(s3service::s3object::DELETE_OBJECT);
			}
			else if (choice == 3)
			{
				objectRequest->set_objectop(s3service::s3object::GET_OBJECT);
			}
		}

		auto requestId = getRequestId();

		std::cout << "Request Id: " << requestId << std::endl;

		request.set_requestid(requestId);

		auto serializedProto = request.SerializeAsString();

		pub->publishMessage(serializedProto, "test");

		sleep(3);
	}
}

void displayConsumedMessage(clientSocket& csRead, s3service::serviceRequestResponse response)
{
	auto entityType = response.entitytype();

	std::cout << "Request Id: " << response.requestid() << std::endl;

	if (entityType == s3service::serviceRequestResponse::ACCOUNT)
	{
		for (int i = 0; i < response.account_size(); i++)
		{
			auto accountResponse = response.account(i);

			auto accountOp = accountResponse.accop();

			if (accountOp == s3service::s3account::CREATE_ACCOUNT)
			{
				if (accountResponse.errorinfo_size() == 0)
				{
					std::cout << "Account created successfully" << std::endl;
					std::cout << "AccountId: " << accountResponse.accountid() << std::endl;

					auto key = accountResponse.keys(0);

					std::cout << "AccessKeyId: " << key.accesskeyid() << std::endl;
					std::cout << "SecretKey: " << key.secretkey() << std::endl;
				}
				else
				{
					s3service::errorDetails error = accountResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while createAccount():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else
			{
				if (accountResponse.errorinfo_size() == 0)
				{
					std::cout << "Account deleted successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = accountResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while deleteAccount():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
		}
	}
	else if (entityType == s3service::serviceRequestResponse::USER)
	{
		for (int i = 0; i < response.user_size(); i++)
		{
			auto userResponse = response.user(i);

			auto userOp = userResponse.userop();

			if (userOp == s3service::s3user::CREATE_USER)
			{
				if (userResponse.errorinfo_size() == 0)
				{
					//userResponse.set_arn("1234");
					std::cout << "User created successfully" << std::endl;
					std::cout << "User Arn: " << userResponse.arn() << std::endl;
					std::cout << "User Id: " << userResponse.userid() << std::endl;
					std::cout << "Test Arn: " << userResponse.test() << std::endl;
					std::cout << "Create Date: " << userResponse.createdate() << std::endl;
				}
				else
				{
					s3service::errorDetails error = userResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while createUser():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (userOp == s3service::s3user::DELETE_USER)
			{
				if (userResponse.errorinfo_size() == 0)
				{
					std::cout << "User deleted successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = userResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error deleteUser():"  << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else
			{
				if (userResponse.errorinfo_size() == 0)
				{
					std::cout << "User updated successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = userResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error updateUser():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
		}
	}
	else if (entityType == s3service::serviceRequestResponse::ACCESSKEY)
	{
		for (int i = 0; i < response.accesskey_size(); i++)
		{
			auto keyResponse = response.accesskey(i);

			auto keyOp = keyResponse.accessop();

			if (keyOp == s3service::s3accesskey::CREATE_KEY)
			{
				if (keyResponse.errorinfo_size() == 0)
				{
					std::cout << "Key created successfully" << std::endl;
					std::cout << "AccessKey: " << keyResponse.accesskeyid() << std::endl;
					std::cout << "SecretKey: " << keyResponse.secretkey() << std::endl;
					std::cout << "AccessKeySelector:" << keyResponse.accesskeyselector() << std::endl;
					std::cout << "CreationDate: " << keyResponse.createdate() << std::endl;
					std::cout << "Status: " << keyResponse.status() << std::endl;
				}
				else
				{
					s3service::errorDetails error = keyResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while createKey():"  << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (keyOp == s3service::s3accesskey::DELETE_KEY)
			{
				if (keyResponse.errorinfo_size() == 0)
				{
					std::cout << "Key deleted successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = keyResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error deleteKey():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (keyOp == s3service::s3accesskey::CHANGE_KEY_STATUS)
			{
				if (keyResponse.errorinfo_size() == 0)
				{
					std::cout << "Key status updated successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = keyResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error changeKeyStatus():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else
			{
				if (keyResponse.errorinfo_size() == 0)
				{
					std::cout << "Last Used Time: " << keyResponse.lastuseddate() << std::endl;
					std::cout << "ServiceName: " << keyResponse.servicename() << std::endl;
				}
				else
				{
					s3service::errorDetails error = keyResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error getLastUsedTime():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
		}
	}
	else if (entityType == s3service::serviceRequestResponse::BUCKET)
	{
		for (int i = 0; i < response.bucket_size(); i++)
		{
			auto bucketResponse = response.bucket(i);

			auto bucketOp = bucketResponse.buckop();

			if (bucketOp == s3service::s3bucket::CREATE_BUCKET)
			{
				if (bucketResponse.errorinfo_size() == 0)
				{
					std::cout << "Bucket created successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = bucketResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while createBucket():"  << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (bucketOp == s3service::s3bucket::DELETE_BUCKET)
			{
				if (bucketResponse.errorinfo_size() == 0)
				{
					std::cout << "Bucket deleted successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = bucketResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error deleteBucket():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (bucketOp == s3service::s3bucket::PUT_BUCKET_TAG)
			{
				if (bucketResponse.errorinfo_size() == 0)
				{
					std::cout << "Bucket Tag updated successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = bucketResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error putBucketTag():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else
			{
				if (bucketResponse.errorinfo_size() == 0)
				{
					std::cout << "Following are all the tags: " << std::endl;

					for (int i = 0; i < bucketResponse.tag_size(); i++)
					{
						std::cout << "Tag" << i+1 << ":" << std::endl;
						auto tag = bucketResponse.tag(i);

						std::cout << tag.key() << "->" << tag.value() << std::endl;
					}
				}
				else
				{
					s3service::errorDetails error = bucketResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error getLastUsedTime():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
		}
	}
	else if (entityType == s3service::serviceRequestResponse::OBJECT)
	{
		for (int i = 0; i < response.object_size(); i++)
		{
			auto objectResponse = response.object(i);

			auto objectOp = objectResponse.objectop();

			if (objectOp == s3service::s3object::PUT_OBJECT)
			{
				if (objectResponse.errorinfo_size() == 0)
				{
					std::cout << "Object created successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = objectResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error while createObject():"  << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (objectOp == s3service::s3object::DELETE_OBJECT)
			{
				if (objectResponse.errorinfo_size() == 0)
				{
					std::cout << "Object deleted successfully" << std::endl;
				}
				else
				{
					s3service::errorDetails error = objectResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error deleteObject():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
			else if (objectOp == s3service::s3object::GET_OBJECT)
			{
				if (objectResponse.errorinfo_size() == 0)
				{
					std::cout << "Object Retrived successfully" << std::endl;
					writeToFile(csRead, objectResponse.objectname(), objectResponse.len());
				}
				else
				{
					s3service::errorDetails error = objectResponse.errorinfo(0);

					auto errorCode = error.errorcode();

					std::cout << "Encountered an error getBucket():" << std::endl;
					std::cout << "Error Type:" << error.errortype() << std::endl;
					std::cout << "Error Code: " << error.errorcode() << std::endl;
					std::cout << "Error Message: " << error.errormessage() << std::endl;
				}
			}
		}
	}
}

int main()
{
	publisher pub("", "", "", "", "requestExchange");

	auto headers = pub.getHeaders();

	headers.insert({"Content-type", "text/text"});
	headers.insert({"Content-encoding", "UTF-8"});

	pub.addHeaders(headers);

	auto err = pub.init();

	if(err.size() != 0)
	{
		std::cout << "Error: " << err << std::endl;
	    return false;
	}

	err = pub.createAndBindQueue("requestQueue", "test");

	if(err.size() != 0)
	{
		std::cout << "Error: " << err << std::endl;
	    return false;
	}

	consumer cObj("", "", "", "", "responseQueue", "client");

	err = cObj.init();

	if (err.size() != 0)
	{
		std::cout << "Error consumer::init(): " << err << std::endl;
		return false;
	}

	err = cObj.bindToExchange("responseExchange", "test");

	if (err.size() != 0)
	{
		std::cout << "Error consumer::bindToExchange(): " << err << std::endl;
		return false;
	}

	clientSocket csRead("127.0.0.1", 9090);
	//clientSocket csWrite("127.0.0.1", 8888);

	 auto ret = csRead.createAndConnect();

	if (ret != "")
	{
		std::cout << "cdRead.createAndConect() failed " << ret << std::endl;
		return -1;
	}
//
//	sleep(5);

//	auto ret = csWrite->createAndConnect();
//
//	if (ret != "")
//	{
//		std::cout << "csWrite.createAndConect() failed " << ret << std::endl;
//		return -1;
//	}

	std::thread th1(&createAndPublishRequestPacket, &pub);

	std::thread th2(&consumer::consumeMessage, &cObj);

	while (true)
	{
		for (size_t i = 0; i < consumer::m_consumeRequestMsg.size(); i++)
		{
			s3service::serviceRequestResponse response;

			response.ParseFromString(consumer::m_consumeRequestMsg[i]);

			std::cout << std::endl;
			std::cout << "*****************************************" << std::endl;
			std::cout << std::endl;

			displayConsumedMessage(csRead, response);

			std::cout << std::endl;
			std::cout << "*****************************************" << std::endl;
			std::cout << std::endl;

			consumer::m_consumeRequestMsg.erase(consumer::m_consumeRequestMsg.begin() + i);
			i--;
		}
	}

	th1.join();
	th2.join();

    return 0;
}
